#Examples

## Color sensor

This [project][ColorSensorProject] uses an MLP ANN to perform classification from RGB values collected using an RGB LED and a light sensor (LDR Cell).

[ColorSensorProject]: http://www.moretticb.com/blog/color-sensor-prototype-using-neural-networks/